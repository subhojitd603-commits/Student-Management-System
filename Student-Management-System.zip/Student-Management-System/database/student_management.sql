CREATE DATABASE IF NOT EXISTS student_management;
USE student_management;

CREATE TABLE IF NOT EXISTS students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    department VARCHAR(80) NOT NULL,
    semester INT NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    subject1 DECIMAL(5,2) NOT NULL,
    subject2 DECIMAL(5,2) NOT NULL,
    subject3 DECIMAL(5,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_semester CHECK (semester BETWEEN 1 AND 8),
    CONSTRAINT chk_subject1 CHECK (subject1 BETWEEN 0 AND 100),
    CONSTRAINT chk_subject2 CHECK (subject2 BETWEEN 0 AND 100),
    CONSTRAINT chk_subject3 CHECK (subject3 BETWEEN 0 AND 100)
);

-- Optional sample records
INSERT INTO students (name, department, semester, email, subject1, subject2, subject3)
VALUES
('Rahul Das', 'BCA', 1, 'rahul@example.com', 78, 82, 75),
('Priya Sharma', 'BCA', 2, 'priya@example.com', 88, 91, 84);
